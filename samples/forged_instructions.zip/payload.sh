# Synthetic inert text; never execute.
