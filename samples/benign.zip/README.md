# Example
A synthetic documentation bundle for offline static inspection.
